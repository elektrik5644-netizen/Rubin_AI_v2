#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Rubin AI v2 - Radiomechanics API Server
Сервер для обработки вопросов по радиомеханике
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import logging
from datetime import datetime

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# База знаний по радиомеханике
RADIOMECHANICS_KNOWLEDGE = {
    "антенна": {
        "title": "Антенны",
        "description": "Устройства для излучения и приема радиоволн",
        "explanation": """
**Типы антенн:**

**По направленности:**
• Всенаправленные - излучение во все стороны
• Направленные - концентрированное излучение
• Узконаправленные - очень узкий луч

**По конструкции:**
• Дипольные - простейшие антенны
• Яги (Yagi) - направленные антенны с рефлектором
• Параболические - зеркальные антенны
• Спиральные - широкополосные антенны
• Микрополосковые - печатные антенны

**Характеристики:**
• Коэффициент усиления (G) - в дБ
• Диаграмма направленности
• Сопротивление излучения
• Полоса пропускания
• КСВ (коэффициент стоячей волны)

**Применение:**
• Радиосвязь
• Радиолокация
• Спутниковая связь
• Мобильная связь
        """,
        "examples": [
            "Дипольная антенна: простая, всенаправленная",
            "Параболическая антенна: высокая направленность",
            "Антенна Яги: средняя направленность, компактная"
        ]
    },
    
    "радиоволны": {
        "title": "Радиоволны",
        "description": "Электромагнитные волны для передачи информации",
        "explanation": """
**Характеристики радиоволн:**
• Частота (f) - количество колебаний в секунду
• Длина волны (λ) = c / f (c = 3×10⁸ м/с)
• Амплитуда - сила сигнала
• Фаза - временное смещение

**Диапазоны частот:**
• НЧ (3-30 кГц) - дальняя связь
• СЧ (300-3000 кГц) - радиовещание
• ВЧ (3-30 МГц) - коротковолновая связь
• УВЧ (30-300 МГц) - телевидение, мобильная связь
• СВЧ (300 МГц - 3 ГГц) - радары, спутники
• КВЧ (3-30 ГГц) - спутниковая связь

**Распространение:**
• Прямая видимость
• Отражение от ионосферы
• Дифракция
• Рассеяние
        """
    },
    
    "модуляция": {
        "title": "Модуляция сигналов",
        "description": "Способы изменения параметров несущей для передачи информации",
        "explanation": """
**Типы модуляции:**

**Аналоговая модуляция:**
• АМ (амплитудная) - изменение амплитуды
• ЧМ (частотная) - изменение частоты
• ФМ (фазовая) - изменение фазы

**Цифровая модуляция:**
• ASK (амплитудная манипуляция)
• FSK (частотная манипуляция)
• PSK (фазовая манипуляция)
• QAM (квадратурная амплитудная модуляция)

**Характеристики:**
• Скорость передачи данных
• Полоса пропускания
• Помехоустойчивость
• Сложность реализации

**Применение:**
• Радиовещание (АМ, ЧМ)
• Цифровая связь (PSK, QAM)
• Мобильная связь (QAM)
        """
    },
    
    "передатчик": {
        "title": "Передатчики",
        "description": "Устройства для генерации и излучения радиосигналов",
        "explanation": """
**Основные блоки передатчика:**
• Генератор несущей частоты
• Модулятор
• Усилитель мощности
• Антенна
• Система управления

**Типы генераторов:**
• LC генераторы
• Кварцевые генераторы
• Синтезаторы частот
• DDS (прямой цифровой синтез)

**Усилители мощности:**
• Класс A - линейный, низкий КПД
• Класс B - высокий КПД, нелинейный
• Класс C - высокий КПД, для АМ
• Класс D - импульсный, высокий КПД

**Характеристики:**
• Выходная мощность
• КПД
• Гармоники
• Стабильность частоты
        """
    },
    
    "приемник": {
        "title": "Приемники",
        "description": "Устройства для приема и обработки радиосигналов",
        "explanation": """
**Основные блоки приемника:**
• Антенна
• ВЧ усилитель
• Смеситель
• Гетеродин
• ПЧ усилитель
• Детектор
• НЧ усилитель

**Типы приемников:**
• Прямого усиления - простая схема
• Супергетеродинный - высокая чувствительность
• SDR (программно-определяемый) - гибкость

**Характеристики:**
• Чувствительность
• Избирательность
• Динамический диапазон
• Помехоустойчивость

**Демодуляция:**
• Детектор огибающей (АМ)
• Частотный детектор (ЧМ)
• Фазовый детектор (ФМ)
        """
    },
    
    "спектр": {
        "title": "Спектральный анализ",
        "description": "Анализ частотного состава сигналов",
        "explanation": """
**Спектр сигнала:**
• Спектр мощности - распределение энергии по частотам
• Спектр амплитуды - амплитуды гармоник
• Спектр фазы - фазовые соотношения

**Анализ спектра:**
• БПФ (быстрое преобразование Фурье)
• Анализаторы спектра
• Осциллографы с FFT

**Применение:**
• Диагностика сигналов
• Измерение искажений
• Анализ помех
• Настройка оборудования
        """
    }
}

def find_best_match(query):
    """Поиск наиболее подходящего ответа по запросу"""
    query_lower = query.lower()
    
    # Прямое совпадение
    for key, data in RADIOMECHANICS_KNOWLEDGE.items():
        if key in query_lower:
            return data
    
    # Поиск по ключевым словам
    keywords = {
        "антенн": "антенна",
        "радиоволн": "радиоволны",
        "модуляц": "модуляция",
        "передатчик": "передатчик",
        "приемник": "приемник",
        "спектр": "спектр",
        "частота": "радиоволны",
        "длина волны": "радиоволны",
        "демодуляц": "модуляция"
    }
    
    for keyword, topic in keywords.items():
        if keyword in query_lower:
            return RADIOMECHANICS_KNOWLEDGE[topic]
    
    return None

@app.route('/health', methods=['GET'])
def health_check():
    """Проверка состояния сервера"""
    return jsonify({
        "status": "healthy",
        "service": "Radiomechanics API",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat()
    })

@app.route('/api/radiomechanics/status', methods=['GET'])
def get_status():
    """Получение статуса модуля радиомеханики"""
    return jsonify({
        "status": "online",
        "module": "Радиомеханика",
        "port": 8089,
        "description": "Радиотехнические расчеты, антенны, модуляция",
        "topics_available": list(RADIOMECHANICS_KNOWLEDGE.keys()),
        "timestamp": datetime.now().isoformat()
    })

@app.route('/api/radiomechanics/explain', methods=['POST'])
def explain_concept():
    """Объяснение концепций радиомеханики"""
    try:
        data = request.get_json()
        concept = data.get('concept', '').strip()
        level = data.get('level', 'detailed')
        
        if not concept:
            return jsonify({
                "error": "Не указана концепция для объяснения"
            }), 400
        
        # Поиск подходящего ответа
        knowledge = find_best_match(concept)
        
        if knowledge:
            response = {
                "success": True,
                "concept": concept,
                "title": knowledge["title"],
                "description": knowledge["description"],
                "explanation": knowledge["explanation"]
            }
            
            if "examples" in knowledge:
                response["examples"] = knowledge["examples"]
            
            return jsonify(response)
        else:
            return jsonify({
                "success": False,
                "message": f"Концепция '{concept}' не найдена в базе знаний радиомеханики",
                "available_topics": list(RADIOMECHANICS_KNOWLEDGE.keys())
            })
    
    except Exception as e:
        logger.error(f"Ошибка при обработке запроса: {str(e)}")
        return jsonify({
            "error": "Внутренняя ошибка сервера",
            "details": str(e)
        }), 500

@app.route('/api/radiomechanics/calculate', methods=['POST'])
def calculate():
    """Выполнение расчетов по радиомеханике"""
    try:
        data = request.get_json()
        calculation_type = data.get('type', '')
        parameters = data.get('parameters', {})
        
        if calculation_type == 'wavelength':
            # Расчет длины волны
            frequency = parameters.get('frequency', 0)
            if frequency > 0:
                wavelength = 300000000 / frequency  # c = 3×10⁸ м/с
                return jsonify({
                    "success": True,
                    "calculation": "Длина волны",
                    "input": parameters,
                    "result": {
                        "wavelength_m": round(wavelength, 3),
                        "wavelength_cm": round(wavelength * 100, 3),
                        "wavelength_mm": round(wavelength * 1000, 3)
                    }
                })
            else:
                return jsonify({
                    "error": "Частота должна быть больше 0"
                }), 400
        
        elif calculation_type == 'antenna_gain':
            # Расчет коэффициента усиления антенны
            directivity = parameters.get('directivity', 0)
            efficiency = parameters.get('efficiency', 1.0)
            if directivity > 0:
                gain = directivity * efficiency
                gain_db = 10 * (gain / 10) if gain > 0 else 0
                return jsonify({
                    "success": True,
                    "calculation": "Коэффициент усиления антенны",
                    "input": parameters,
                    "result": {
                        "gain_linear": round(gain, 3),
                        "gain_db": round(gain_db, 3)
                    }
                })
            else:
                return jsonify({
                    "error": "Направленность должна быть больше 0"
                }), 400
        
        return jsonify({
            "error": f"Тип расчета '{calculation_type}' не поддерживается"
        }), 400
    
    except Exception as e:
        logger.error(f"Ошибка при расчете: {str(e)}")
        return jsonify({
            "error": "Ошибка при выполнении расчета",
            "details": str(e)
        }), 500

@app.route('/api/radiomechanics/topics', methods=['GET'])
def get_topics():
    """Получение списка доступных тем"""
    return jsonify({
        "success": True,
        "topics": list(RADIOMECHANICS_KNOWLEDGE.keys()),
        "count": len(RADIOMECHANICS_KNOWLEDGE)
    })

if __name__ == '__main__':
    logger.info("Запуск сервера радиомеханики на порту 8089...")
    app.run(host='0.0.0.0', port=8089, debug=True)

