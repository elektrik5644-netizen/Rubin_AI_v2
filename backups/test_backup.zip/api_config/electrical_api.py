#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Rubin AI v2 - Electrical Engineering API Server
Сервер для обработки вопросов по электротехнике
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import logging
from datetime import datetime

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# База знаний по электротехнике
ELECTRICAL_KNOWLEDGE = {
    "закон ома": {
        "title": "Закон Ома",
        "description": "Основной закон электротехники, связывающий напряжение, ток и сопротивление",
        "formula": "U = I × R",
        "explanation": """
**Закон Ома для участка цепи:**
• U = I × R (напряжение = ток × сопротивление)
• I = U / R (ток = напряжение / сопротивление)  
• R = U / I (сопротивление = напряжение / ток)

**Закон Ома для полной цепи:**
• I = E / (R + r)
• E - ЭДС источника
• R - внешнее сопротивление
• r - внутреннее сопротивление источника

**Применение:**
• Расчет токов в цепях
• Выбор резисторов
• Анализ цепей постоянного тока
        """,
        "examples": [
            "При напряжении 12В и сопротивлении 4Ом ток = 12/4 = 3А",
            "При токе 2А и сопротивлении 6Ом напряжение = 2×6 = 12В"
        ]
    },
    
    "закон кирхгофа": {
        "title": "Законы Кирхгофа",
        "description": "Фундаментальные законы для анализа электрических цепей",
        "explanation": """
**Первый закон Кирхгофа (закон токов):**
• Сумма токов, входящих в узел = сумме токов, выходящих из узла
• ΣIвх = ΣIвых

**Второй закон Кирхгофа (закон напряжений):**
• Сумма ЭДС в замкнутом контуре = сумме падений напряжений
• ΣE = Σ(I×R)

**Применение:**
• Анализ сложных цепей
• Расчет токов в разветвленных цепях
• Проверка правильности расчетов
        """,
        "examples": [
            "В узле: I1 + I2 = I3 + I4",
            "В контуре: E1 - E2 = I1×R1 + I2×R2"
        ]
    },
    
    "мощность": {
        "title": "Электрическая мощность",
        "description": "Мощность в электрических цепях",
        "formula": "P = U × I = I² × R = U² / R",
        "explanation": """
**Формулы мощности:**
• P = U × I (мощность = напряжение × ток)
• P = I² × R (мощность = ток² × сопротивление)
• P = U² / R (мощность = напряжение² / сопротивление)

**Единицы измерения:**
• Ватт (Вт) - основная единица
• Киловатт (кВт) = 1000 Вт
• Мегаватт (МВт) = 1000000 Вт

**Применение:**
• Расчет потребляемой мощности
• Выбор проводов и защитных устройств
• Энергетические расчеты
        """
    },
    
    "резистор": {
        "title": "Резисторы",
        "description": "Пассивные элементы, ограничивающие ток в цепи",
        "explanation": """
**Типы резисторов:**
• Постоянные - фиксированное сопротивление
• Переменные (потенциометры) - регулируемое сопротивление
• Термисторы - сопротивление зависит от температуры

**Маркировка:**
• Цветовая кодировка (4-6 полос)
• Цифровая маркировка
• SMD маркировка

**Соединения:**
• Последовательное: Rобщ = R1 + R2 + R3
• Параллельное: 1/Rобщ = 1/R1 + 1/R2 + 1/R3
        """
    },
    
    "конденсатор": {
        "title": "Конденсаторы",
        "description": "Элементы, накапливающие электрический заряд",
        "explanation": """
**Принцип работы:**
• Накопление заряда на обкладках
• Емкость C = Q / U
• Энергия W = C × U² / 2

**Типы конденсаторов:**
• Керамические - малые размеры, стабильность
• Электролитические - большая емкость
• Пленочные - высокое качество

**Применение:**
• Фильтрация сигналов
• Развязка цепей
• Временные задержки
        """
    },
    
    "modbus": {
        "title": "Протокол Modbus",
        "description": "Промышленный протокол связи для автоматизации",
        "explanation": """
**Modbus RTU:**
• Последовательная связь (RS-485, RS-232)
• Бинарный формат данных
• CRC контрольная сумма
• Адресация устройств (1-247)

**Функции Modbus:**
• 01 - Чтение дискретных выходов
• 02 - Чтение дискретных входов  
• 03 - Чтение регистров хранения
• 04 - Чтение входных регистров
• 05 - Запись одного выхода
• 06 - Запись одного регистра

**Структура кадра:**
• Адрес устройства (1 байт)
• Код функции (1 байт)
• Данные (N байт)
• CRC (2 байта)

**Применение:**
• PLC системы
• SCADA системы
• Промышленные сети
        """
    }
}

def find_best_match(query):
    """Поиск наиболее подходящего ответа по запросу"""
    query_lower = query.lower()
    
    # Прямое совпадение
    for key, data in ELECTRICAL_KNOWLEDGE.items():
        if key in query_lower:
            return data
    
    # Поиск по ключевым словам
    keywords = {
        "ом": "закон ома",
        "кирхгоф": "закон кирхгофа", 
        "мощность": "мощность",
        "резистор": "резистор",
        "конденсатор": "конденсатор",
        "modbus": "modbus",
        "напряжение": "закон ома",
        "ток": "закон ома",
        "сопротивление": "закон ома"
    }
    
    for keyword, topic in keywords.items():
        if keyword in query_lower:
            return ELECTRICAL_KNOWLEDGE[topic]
    
    return None

@app.route('/health', methods=['GET'])
def health_check():
    """Проверка состояния сервера"""
    return jsonify({
        "status": "healthy",
        "service": "Electrical Engineering API",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat()
    })

@app.route('/api/electrical/status', methods=['GET'])
def get_status():
    """Получение статуса модуля электротехники"""
    return jsonify({
        "status": "online",
        "module": "Электротехника",
        "port": 8087,
        "description": "Расчеты электрических цепей, схемы, закон Ома, Кирхгофа",
        "topics_available": list(ELECTRICAL_KNOWLEDGE.keys()),
        "timestamp": datetime.now().isoformat()
    })

@app.route('/api/electrical/explain', methods=['POST'])
def explain_concept():
    """Объяснение концепций электротехники"""
    try:
        data = request.get_json()
        concept = data.get('concept', '').strip()
        level = data.get('level', 'detailed')
        
        if not concept:
            return jsonify({
                "error": "Не указана концепция для объяснения"
            }), 400
        
        # Поиск подходящего ответа
        knowledge = find_best_match(concept)
        
        if knowledge:
            response = {
                "success": True,
                "concept": concept,
                "title": knowledge["title"],
                "description": knowledge["description"],
                "explanation": knowledge["explanation"]
            }
            
            if "formula" in knowledge:
                response["formula"] = knowledge["formula"]
            
            if "examples" in knowledge:
                response["examples"] = knowledge["examples"]
            
            return jsonify(response)
        else:
            return jsonify({
                "success": False,
                "message": f"Концепция '{concept}' не найдена в базе знаний электротехники",
                "available_topics": list(ELECTRICAL_KNOWLEDGE.keys())
            })
    
    except Exception as e:
        logger.error(f"Ошибка при обработке запроса: {str(e)}")
        return jsonify({
            "error": "Внутренняя ошибка сервера",
            "details": str(e)
        }), 500

@app.route('/api/electrical/calculate', methods=['POST'])
def calculate():
    """Выполнение расчетов по электротехнике"""
    try:
        data = request.get_json()
        calculation_type = data.get('type', '')
        parameters = data.get('parameters', {})
        
        if calculation_type == 'ohm_law':
            # Расчет по закону Ома
            if 'voltage' in parameters and 'resistance' in parameters:
                current = parameters['voltage'] / parameters['resistance']
                power = parameters['voltage'] * current
                return jsonify({
                    "success": True,
                    "calculation": "Закон Ома",
                    "input": parameters,
                    "result": {
                        "current": round(current, 3),
                        "power": round(power, 3)
                    }
                })
            elif 'current' in parameters and 'resistance' in parameters:
                voltage = parameters['current'] * parameters['resistance']
                power = voltage * parameters['current']
                return jsonify({
                    "success": True,
                    "calculation": "Закон Ома",
                    "input": parameters,
                    "result": {
                        "voltage": round(voltage, 3),
                        "power": round(power, 3)
                    }
                })
            else:
                return jsonify({
                    "error": "Недостаточно параметров для расчета по закону Ома"
                }), 400
        
        return jsonify({
            "error": f"Тип расчета '{calculation_type}' не поддерживается"
        }), 400
    
    except Exception as e:
        logger.error(f"Ошибка при расчете: {str(e)}")
        return jsonify({
            "error": "Ошибка при выполнении расчета",
            "details": str(e)
        }), 500

@app.route('/api/electrical/topics', methods=['GET'])
def get_topics():
    """Получение списка доступных тем"""
    return jsonify({
        "success": True,
        "topics": list(ELECTRICAL_KNOWLEDGE.keys()),
        "count": len(ELECTRICAL_KNOWLEDGE)
    })

if __name__ == '__main__':
    logger.info("Запуск сервера электротехники на порту 8087...")
    app.run(host='0.0.0.0', port=8087, debug=True)

