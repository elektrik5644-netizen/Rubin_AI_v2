#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Rubin AI v2 - Controllers API Server
Сервер для обработки вопросов по контроллерам и промышленной автоматизации
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import logging
from datetime import datetime

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# База знаний по контроллерам
CONTROLLERS_KNOWLEDGE = {
    "pmac": {
        "title": "PMAC контроллеры",
        "description": "Программируемые многоосевые контроллеры движения",
        "explanation": """
**PMAC (Programmable Multi-Axis Controller):**

**Основные возможности:**
• Управление до 32 осями одновременно
• Высокая точность позиционирования (до 0.1 мкм)
• Встроенная математика для траекторий
• Работа в реальном времени (1 мс цикл)

**Архитектура:**
• **DSP** - цифровой сигнальный процессор
• **Память программ** - хранение алгоритмов
• **Память данных** - переменные и параметры
• **Интерфейсы** - энкодеры, аналоговые входы

**Языки программирования:**
• **Motion Programs** - программы движения
• **PLC Programs** - логика управления
• **Background Programs** - фоновые задачи

**Основные функции:**
• **Позиционирование** - точное позиционирование осей
• **Интерполяция** - плавные траектории движения
• **Синхронизация** - координация нескольких осей
• **Обратная связь** - контроль положения и скорости

**Применение:**
• Станки с ЧПУ
• Робототехника
• Измерительные системы
• Промышленная автоматизация
        """,
        "examples": [
            "3-осевой фрезерный станок",
            "6-осевой робот-манипулятор",
            "Координатно-измерительная машина"
        ]
    },
    
    "plc": {
        "title": "PLC контроллеры",
        "description": "Программируемые логические контроллеры",
        "explanation": """
**PLC (Programmable Logic Controller):**

**Основные функции:**
• Логическое управление процессами
• Обработка дискретных и аналоговых сигналов
• Работа в реальном времени
• Высокая надежность

**Языки программирования:**
• **Ladder Logic (LD)** - релейная логика
• **Structured Text (ST)** - текстовый язык
• **Function Block Diagram (FBD)** - функциональные блоки
• **Instruction List (IL)** - низкоуровневые инструкции

**Популярные производители:**
• **Siemens** - S7-1200, S7-1500, TIA Portal
• **Allen-Bradley** - CompactLogix, ControlLogix, Studio 5000
• **Schneider Electric** - Modicon, Unity Pro
• **Omron** - CP1, CJ2, CX-Programmer

**Применение:**
• Промышленная автоматизация
• Управление процессами
• Системы безопасности
• Мониторинг оборудования
        """
    },
    
    "энкодер": {
        "title": "Энкодеры",
        "description": "Датчики обратной связи для измерения положения и скорости",
        "explanation": """
**Энкодеры - датчики обратной связи:**

**Типы энкодеров:**
• **Инкрементальные** - относительное положение
• **Абсолютные** - абсолютное положение
• **Линейные** - прямолинейное движение
• **Ротационные** - вращательное движение

**Принцип работы:**
• **Оптические** - светодиод + фотодиод
• **Магнитные** - магнитное поле + датчик Холла
• **Индуктивные** - электромагнитная индукция
• **Емкостные** - изменение емкости

**Разрешение:**
• **PPR** - импульсы на оборот
• **CPR** - циклы на оборот
• **Биты** - для абсолютных энкодеров

**Применение:**
• Серводвигатели
• Шаговые двигатели
• Позиционирование осей
• Измерение скорости
        """
    },
    
    "сервопривод": {
        "title": "Сервоприводы",
        "description": "Точные приводы с обратной связью",
        "explanation": """
**Сервоприводы - точные приводы:**

**Компоненты:**
• **Двигатель** - AC или DC
• **Энкодер** - датчик обратной связи
• **Контроллер** - управление движением
• **Усилитель** - питание двигателя

**Типы управления:**
• **Позиционное** - точное позиционирование
• **Скоростное** - управление скоростью
• **Моментное** - управление усилием
• **Комбинированное** - несколько режимов

**Характеристики:**
• Высокая точность позиционирования
• Быстрый отклик
• Широкий диапазон скоростей
• Плавное движение

**Применение:**
• Станки с ЧПУ
• Робототехника
• Промышленные манипуляторы
• Измерительные системы
        """
    }
}

def find_best_match(query):
    """Поиск наиболее подходящего ответа по запросу"""
    query_lower = query.lower()
    
    # Прямое совпадение
    for key, data in CONTROLLERS_KNOWLEDGE.items():
        if key in query_lower:
            return data
    
    # Поиск по ключевым словам
    keywords = {
        "pmac": "pmac",
        "plc": "plc",
        "энкодер": "энкодер",
        "сервопривод": "сервопривод",
        "контроллер": "plc",
        "автоматизация": "plc"
    }
    
    for keyword, topic in keywords.items():
        if keyword in query_lower:
            return CONTROLLERS_KNOWLEDGE[topic]
    
    return None

@app.route('/health', methods=['GET'])
def health_check():
    """Проверка состояния сервера"""
    return jsonify({
        "status": "healthy",
        "service": "Controllers API",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat()
    })

@app.route('/api/controllers/status', methods=['GET'])
def get_status():
    """Получение статуса модуля контроллеров"""
    return jsonify({
        "status": "online",
        "module": "Контроллеры",
        "port": 8090,
        "description": "PMAC, PLC, микроконтроллеры, промышленная автоматизация",
        "topics_available": list(CONTROLLERS_KNOWLEDGE.keys()),
        "timestamp": datetime.now().isoformat()
    })

@app.route('/api/controllers/topic/<topic>', methods=['POST'])
def explain_topic(topic):
    """Объяснение тем по контроллерам"""
    try:
        data = request.get_json()
        concept = data.get('concept', topic)
        
        # Поиск подходящего ответа
        knowledge = find_best_match(concept)
        
        if knowledge:
            response = {
                "success": True,
                "concept": concept,
                "title": knowledge["title"],
                "description": knowledge["description"],
                "explanation": knowledge["explanation"]
            }
            
            if "examples" in knowledge:
                response["examples"] = knowledge["examples"]
            
            return jsonify(response)
        else:
            return jsonify({
                "success": False,
                "message": f"Тема '{concept}' не найдена в базе знаний контроллеров",
                "available_topics": list(CONTROLLERS_KNOWLEDGE.keys())
            })
    
    except Exception as e:
        logger.error(f"Ошибка при обработке запроса: {str(e)}")
        return jsonify({
            "error": "Внутренняя ошибка сервера",
            "details": str(e)
        }), 500

@app.route('/api/controllers/topics', methods=['GET'])
def get_topics():
    """Получение списка доступных тем"""
    return jsonify({
        "success": True,
        "topics": list(CONTROLLERS_KNOWLEDGE.keys()),
        "count": len(CONTROLLERS_KNOWLEDGE)
    })

if __name__ == '__main__':
    logger.info("Запуск сервера контроллеров на порту 8090...")
    app.run(host='0.0.0.0', port=8090, debug=True)

